extern void dsrand_ts(unsigned);
extern double drand_ts(void);
extern void dsrand_parallel_ts(unsigned);
extern double drand_parallel_ts(void);